/**
 * overtaker - Sample application for overtaking obstacles.
 * Copyright (C) 2012 - 2015 Christian Berger
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <cstdio>
#include <cmath>
 #include <iostream>


#include "opendavinci/odcore/io/conference/ContainerConference.h"
#include "opendavinci/odcore/data/Container.h"
 #include "automotivedata/generated/automotive/miniature/SteeringData.h"

#include "opendavinci/GeneratedHeaders_OpenDaVINCI.h"
#include "automotivedata/GeneratedHeaders_AutomotiveData.h"

#include "Overtaker.h"

namespace automotive {
    namespace miniature {

        using namespace std;
        using namespace odcore::base;
        using namespace odcore::data;
        using namespace automotive;
        using namespace automotive::miniature;

        Overtaker::Overtaker(const int32_t &argc, char **argv) :
            TimeTriggeredConferenceClientModule(argc, argv, "overtakeing") {
                }

        Overtaker::~Overtaker() {}
        
        void Overtaker::setUp(){
        // This method will be call automatically _before_ running body().
        }

        void Overtaker::tearDown() {
            // This method will be call automatically _after_ return from body().
        }
        
      
       // This method will do the main data processing job.
    odcore::data::dmcp::ModuleExitCodeMessage::ModuleExitCode Overtaker::body() {
    

    

    enum State {    	
		 TURN_LEFT,    	
         CALL_LANEDETECTOR,       
         TURN_RIGHT,       
    };

    State state = CALL_LANEDETECTOR; 
    
    int theCount =0;
   

    while (getModuleStateAndWaitForRemainingTimeInTimeslice() == odcore::data::dmcp::ModuleStateMessage::RUNNING) {
                // 1. Get most recent vehicle data:
                Container containerVehicleData = getKeyValueDataStore().get(VehicleData::ID());
                VehicleData vd = containerVehicleData.getData<VehicleData> ();
            
               

                // 2. Get most recent sensor board data:
                Container containerSensorBoardData = getKeyValueDataStore().get(automotive::miniature::SensorBoardData::ID());
                SensorBoardData sbd = containerSensorBoardData.getData<SensorBoardData> ();
              
                
                

                // 3. Get most recent steering data as fill from lanedetector for example:
                Container containerSteeringData = getKeyValueDataStore().get(
                SteeringData::ID());
                SteeringData sd = containerSteeringData.getData<SteeringData>();
                
                
                double theAngle = sd.getExampleData(); 
               

                // Create vehicle control data.
                VehicleControl vc;

//--------------------------------------------------------------------------------------------



//all values are based in the real world!

        switch (state) {
        	case CALL_LANEDETECTOR:
        		cout << "STATE : lanedetector" << theAngle <<endl;
        		theAngle=sd.getExampleData();
        		vc.setSpeed(1);
        		vc.setSteeringWheelAngle(theAngle);
        		if(sbd.getValueForKey_MapOfDistances(3) > 30 && sbd.getValueForKey_MapOfDistances(3) < 50){ //detect object in front
        			state = TURN_LEFT;
        		}
        		break;

        	case TURN_LEFT:
        		vc.setSteeringWheelAngle(-35);
        		vc.setSpeed(1);
        		cout << "STATE : TURN_LEFT -------" << sbd.getValueForKey_MapOfDistances(2) <<endl;
        		if(sbd.getValueForKey_MapOfDistances(2) >50){ //detect object on the right with the 1st sensor
        			state = TURN_RIGHT;
        		}
        		
        		break;
        	case TURN_RIGHT:
        		vc.setSteeringWheelAngle(35);
        		vc.setSpeed(1);
        		cout << "STATE : TURN_RIGHT ------" << sbd.getValueForKey_MapOfDistances(0) <<endl;
        		if(sbd.getValueForKey_MapOfDistances(0) < 50 ){ // RearRight sensor detects nothing
        			theCount++; // this is a delay so the car gets in a good position to call the lanedetector(based in the real world)
        			if (theCount ==10){
        				state = CALL_LANEDETECTOR;
        			}
        		}
        		
        		break;
       	}

        Container c(vc);;
        // Send container.
        getConference().send(c);
        
        }
        return odcore::data::dmcp::ModuleExitCodeMessage::OKAY;
    }
    }
}