/**
 * lanedetector - Application skeleton for detecting lane markings.
 * Copyright (C) 2012 - 2015 Christian Berger
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
 
#include <iostream>
#include <memory>
 
#include <opencv/cv.h>
#include <opencv/highgui.h>
 
#include "opendavinci/odcore/base/KeyValueConfiguration.h"
#include "opendavinci/odcore/base/Lock.h"
#include "opendavinci/odcore/data/Container.h"
#include "opendavinci/odcore/wrapper/SharedMemoryFactory.h"
 
#include "opendavinci/odtools/player/Player.h"
 
#include "opendavinci/GeneratedHeaders_OpenDaVINCI.h"
#include "automotivedata/GeneratedHeaders_AutomotiveData.h"
 
#include "LaneDetector.h"
#include <unistd.h>
 
 
namespace automotive {
    namespace miniature {
 
        using namespace std;
        using namespace odcore::base;
        using namespace odcore::base::module;
        using namespace odcore::data;
        using namespace odcore::data::image;
        using namespace odtools::player;
        using namespace automotive;
        using namespace cv;
 
        void LaneDetector::verticalLine( cv::Mat img, cv::Point start, cv::Point end )  //these are the line attributes
        {
            int thickness = 1;
            int lineType = 8;
            line( img,
                start,
                end,
                cv::Scalar( 0, 0, 255 ),
                thickness,
                lineType );
        }
        void LaneDetector::rightArrow( cv::Mat img, cv::Point start, cv::Point end )
        {
            int thickness = 1;
            int lineType = 8;
            line( img,
                start,
                end,
                cv::Scalar( 98, 206, 81 ),
                thickness,
                lineType );
        }
        void LaneDetector::leftArrow( cv::Mat img, cv::Point start, cv::Point end )
        {
            int thickness = 1;
            int lineType = 8;
            line( img,
                start,
                end,
                cv::Scalar(255,154,0 ),
                thickness,
                lineType );
        }
        bool LaneDetector::IsWhite(cv::Mat img, int y, int x){
            int blue = img.at<cv::Vec3b>(y,x)[0];
             //blue = intensity.val[0];
             int green = img.at<cv::Vec3b>(y,x)[1];
             int red = img.at<cv::Vec3b>(y,x)[2];
 
            if(blue == 255 && green == 255 && red == 255){
                return true;
            }
            return false;
        }
 
        LaneDetector::LaneDetector(const int32_t &argc, char **argv) :
            TimeTriggeredConferenceClientModule(argc, argv, "LaneDetector"),
            m_hasAttachedToSharedImageMemory(false),
            m_sharedImageMemory(),
            m_image(NULL),
            m_debug(false) {}
 
        LaneDetector::~LaneDetector() {}
 
        void LaneDetector::setUp() {
            // This method will be called automatically _before_ running body().
 
            // If in debug mode, display the image from the camera feed.
            if (m_debug) {
                cvNamedWindow("Camera Feed Image", CV_WINDOW_AUTOSIZE);
                cvMoveWindow("Camera Feed Image", 300, 100);
            }
        }
 
        void LaneDetector::tearDown() {
            // This method will be called automatically _after_ return from body().
            cout << "Control C is pressed" << endl;
            if (m_image != NULL) {
                cvReleaseImage(&m_image);
 
            }
 
            if (m_debug) {
                cvDestroyWindow("Camera Feed Image");
            }
        }
 
        bool LaneDetector::readSharedImage(Container &c) {
            bool retVal = false;
 
            if (c.getDataType() == odcore::data::image::SharedImage::ID()) {
                SharedImage si = c.getData<SharedImage> ();
 
                // Check if we have already attached to the shared memory containing the image from the virtual camera.
                if (!m_hasAttachedToSharedImageMemory) {
                    m_sharedImageMemory = odcore::wrapper::SharedMemoryFactory::attachToSharedMemory(si.getName());
                }
 
                // Check if we could successfully attach to the shared memory.
                if (m_sharedImageMemory->isValid()) {
                    // Lock the memory region to gain exclusive access using a scoped lock.
                    Lock l(m_sharedImageMemory);
 
                    if (m_image == NULL) {
                        m_image = cvCreateImage(cvSize(si.getWidth(), si.getHeight()), IPL_DEPTH_8U, si.getBytesPerPixel());
                    }
 
                    // Example: Simply copy the image into our process space.
                    if (m_image != NULL) {
                        memcpy(m_image->imageData, m_sharedImageMemory->getSharedMemory(), si.getWidth() * si.getHeight() * si.getBytesPerPixel());
                    }
 
                    // Mirror the image.
                    // in the real world you have to comment this out
                    cvFlip(m_image, 0, -1);
 
                    retVal = true;
                }
            }
            return retVal;
        }
 
        // This method is called to process an image described by the SharedImage data structure.
        void LaneDetector::processImage() {
            // Example: Show the image.
            if (m_debug) {
                cv::Mat mat_img(m_image); //converts the IPL image to a mat image
                IplImage *img_gray = cvCreateImage(cvGetSize(m_image),IPL_DEPTH_8U,1);
        IplImage *canny_image = cvCreateImage(cvGetSize(m_image),IPL_DEPTH_8U,1);
 
        //convert image to Canny image
        cvCvtColor(m_image,img_gray, CV_RGB2GRAY);// makes image gray
        cvCanny(img_gray, canny_image, 100, 150, 3 );// canny edge detection
        cvCvtColor(canny_image, m_image, CV_GRAY2RGB);
 
        //Release filtered image
        cvReleaseImage(&img_gray);
        cvReleaseImage(&canny_image);
                int rows = mat_img.rows;
                int cols = mat_img.cols;
                // cv::Size s = mat_img.size(); //gets rows and columns
                // rows = s.height;
                // cols = s.width;
                cv::Point pt1; //initialize the startin and ending points for each arrow
                cv::Point pt2;
                cv::Point pt3;
                cv::Point pt4;
                cv::Point pt5;
                cv::Point pt6;
                cv::Point pt7;
                cv::Point pt8;
                cv::Point pt9;
                cv::Point pt10;
                cv::Point pt11;
               
 
       
                pt1.x=cols/2; //starting points for first arrow
                pt1.y=0;
                pt2.x=cols/2; //ending points for first arrow
                pt2.y=rows;
 
                pt3.x=cols/2;
                pt3.y=350; // the point where the lines will start horizontally
                pt4.x = pt3.x;
                pt4.y = pt3.y;
                pt5.x = pt3.x;
                pt5.y = pt3.y;
                pt6.x = pt3.x;
                pt6.y = 390;//the point where the lines will start horizontally 
                pt7.x = pt6.x;
                pt7.y = pt6.y;
                pt8.x = pt3.x;
                pt8.y = 310;
                pt9.x = pt8.x;
                pt9.y = pt8.y;
                pt10.y = 270;
                pt10.x = pt3.x;
                pt11.y = pt10.y;               
                pt11.x = pt10.x;   
                //this is the only right line
                while(pt4.x != cols){
                    pt4.x = pt4.x +1; //extend the arrow
                     //checks for color at current position
                    if(IsWhite(mat_img,pt4.y,pt4.x)){
                        break; //color is white at current position
                    }
                }
                rightArrow(mat_img, pt3, pt4);
                //below there are the left lines.
                while(pt5.x != 0){
                    pt5.x = pt5.x -1;
                    if(IsWhite(mat_img,pt5.y,pt5.x)){
                        break; //color is white at current position
                    }
                }
                leftArrow(mat_img, pt3, pt5);
                while(pt7.x != 0){
                    pt7.x = pt7.x -1;
                    if(IsWhite(mat_img,pt7.y,pt7.x)){
                        break; //color is white at current position
                    }
                }
                leftArrow(mat_img, pt6, pt7);
                while(pt9.x != 0){
                    pt9.x = pt9.x -1;
                    if(IsWhite(mat_img,pt9.y,pt9.x)){
                        break; //color is white at current position
                    }
                }
                leftArrow(mat_img, pt8, pt9);
                while(pt11.x != 0){
                    pt11.x = pt11.x -1;
                    if(IsWhite(mat_img,pt11.y,pt11.x)){
                        break; //color is white at current position
                    }
                }
                leftArrow(mat_img, pt10, pt11);
                //vertical arrow
               
                while(pt1.y != rows){
                    pt1.y = pt1.y +1;
                    //cout << "line detected" << endl;
                    if(IsWhite(mat_img,pt1.y,pt1.x)){
                        break; //color is white at current position
                    }
                }
                verticalLine(mat_img, pt1, pt2);
 
                if (m_image != NULL) {
                    cvShowImage("Camera Feed Image", m_image);
                    cvWaitKey(10);
                }
                //if you use overtaker you need to uncomment this out.
                //Container containerSteeringData = getKeyValueDataStore().get(SteeringData::ID());
                //SteeringData sd = containerSteeringData.getData<SteeringData>();
                Container containerVC = getKeyValueDataStore().get(VehicleControl::ID());
                VehicleControl vc = containerVC.getData<VehicleControl>(); ;
                vc.setSpeed(1);

                double angle = 0.0;
                
                //checks right line
                if(pt4.x < 640 && pt4.x > 550 ){
                    angle = 26.0;
                    vc.setSteeringWheelAngle(angle); //sends the steering data to the vehicle control
                    cout << "1st one" << pt4.x<<endl;
                    //sd.setExampleData(angle);
 
                }else if(pt4.x<440 && pt4.x>320 ){
                    angle = -17;
                    cout << "2nd one" << pt4.x <<endl;
                    vc.setSteeringWheelAngle(angle);
                    //sd.setExampleData(angle); // this is used to send data to the "steeringdata" and use it in the overtaking as the angle.
                }

                //checks left line
                //Middle blue line
                else if(pt11.x > 150){
                    cout << "3th one "  << pt11.x <<endl;
                    angle = +20.0;
                    vc.setSteeringWheelAngle(angle); //sends the steering data to the vehicle control
                   // sd.setExampleData(angle);
                }
                else if(pt5.x > 150 ){
                    angle = +20.0;
                    cout << "4rd one" << pt5.x <<endl;
                    vc.setSteeringWheelAngle(angle); //sends the steering data to the vehicle control
                    //sd.setExampleData(angle);
                   
                }
                //Front Blue line 2
                else if(pt9.x > 150){
                    cout << "5th one" <<pt9.x <<endl;
                    angle = +20.0;
                    vc.setSteeringWheelAngle(angle); //sends the steering data to the vehicle control
                    //sd.setExampleData(angle);
                }
                //Front Blue line 1
               
               
                //Back Blue line
                else if(pt7.x > 100) {
                    cout << "6th one" << pt7.x<<endl;
                    angle = +20.0;
                    vc.setSteeringWheelAngle(angle);
                    //sd.setExampleData(angle);
                }
            
                Container c(vc);
                //Container c(sd);
                // Send container.
                getConference().send(c);
               
            }
           
        }
 
        // This method will do the main data processing job.
        // Therefore, it tries to open the real camera first. If that fails, the virtual camera images from camgen are used.
        odcore::data::dmcp::ModuleExitCodeMessage::ModuleExitCode LaneDetector::body() {
 

 
            // Get configuration data.
            KeyValueConfiguration kv = getKeyValueConfiguration();
            m_debug = kv.getValue<int32_t> ("lanedetector.debug") == 1;
 
            unique_ptr<Player> player;
/*
            // Lane-detector can also directly read the data from file. This might be interesting to inspect the algorithm step-wisely.
            odcore::io::URL url("file://recording.rec");
            // Size of the memory buffer.
            const uint32_t MEMORY_SEGMENT_SIZE = kv.getValue<uint32_t>("global.buffer.memorySegmentSize");
            // Number of memory segments.
            const uint32_t NUMBER_OF_SEGMENTS = kv.getValue<uint32_t>("global.buffer.numberOfMemorySegments");
            // If AUTO_REWIND is true, the file will be played endlessly.
            const bool AUTO_REWIND = true;
            // We do not want player to run in parallel but we want to process frame by frame sequentially.
            const bool THREADING = false;
            // Construct the player.
            player = unique_ptr<Player>(new Player(url, AUTO_REWIND, MEMORY_SEGMENT_SIZE, NUMBER_OF_SEGMENTS, THREADING));
*/
 
            // Main data processing loop.
            while (getModuleStateAndWaitForRemainingTimeInTimeslice() == odcore::data::dmcp::ModuleStateMessage::RUNNING) {
                //cout << "Hello" << endl;
                bool has_next_frame = false;
 
                // Use the shared memory image.
                Container c;
                if (player.get() != NULL) {
                    // Read the next container from file.
                    c = player->getNextContainerToBeSent();
                }
                else {
                    // Get the most recent available container for a SHARED_IMAGE.
                    c = getKeyValueDataStore().get(odcore::data::image::SharedImage::ID());
                }
 
                if (c.getDataType() == odcore::data::image::SharedImage::ID()) {
                    // Example for processing the received container.
                    has_next_frame = readSharedImage(c);
                }
 
                // Process the read image.
                if (true == has_next_frame) {
                    processImage();
                }
            }
 
            return odcore::data::dmcp::ModuleExitCodeMessage::OKAY;
        }
 
    } // miniature
} // automotive