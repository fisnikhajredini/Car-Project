/**
 * proxy - Sample application to encapsulate HW/SW interfacing with embedded systems.
 * Copyright (C) 2012 - 2015 Christian Berger
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
 #ifndef WIN32
 # if !defined(__OpenBSD__) && !defined(__NetBSD__)
 #  pragma GCC diagnostic push
 # endif
 # pragma GCC diagnostic ignored "-Weffc++"
 #endif
     #include "serial/serial.h"
 #ifndef WIN32
 # if !defined(__OpenBSD__) && !defined(__NetBSD__)
 #  pragma GCC diagnostic pop
 # endif
 #endif

#include <ctype.h>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cstdio>
#include <unistd.h> // Linux specific
#include <string>
#include <automotivedata/GeneratedHeaders_AutomotiveData.h>

#include "opendavinci/odcore/base/KeyValueConfiguration.h"
#include "opendavinci/odcore/data/Container.h"
#include "opendavinci/odcore/data/TimeStamp.h"
#include "serial/serial.h"

#include "OpenCVCamera.h"

#ifdef HAVE_UEYE
    #include "uEyeCamera.h"
#endif

#include "Proxy.h"

//  int counterFR;
//           //int ArrayCounterFR=0;
//           //int ArrayCounterRR=0;
// int counterRR;
// int averageFR;
// int averageRR;
// int IRFR[4];
// int IRRR[4];


namespace automotive {
    namespace miniature {

        using namespace std;
        using namespace odcore::base;
        using namespace odcore::data;
        using namespace odtools::recorder;

        Proxy::Proxy(const int32_t &argc, char **argv) :
            TimeTriggeredConferenceClientModule(argc, argv, "proxy"),
            m_recorder(),
            m_camera()
        {}

        Proxy::~Proxy() {
        }

        void Proxy::setUp() {
            // This method will be call automatically _before_ running body().
            if (getFrequency() < 20) {
                cerr << endl << endl << "Proxy: WARNING! Running proxy with a LOW frequency (consequence: data updates are too seldom and will influence your algorithms in a negative manner!) --> suggestions: --freq=20 or higher! Current frequency: " << getFrequency() << " Hz." << endl << endl << endl;
            }
            // counterFR=0;
            // counterRR=0;
            // averageFR=0;
            // averageRR=0;
            // Get configuration data.
            KeyValueConfiguration kv = getKeyValueConfiguration();
        // Create built-in recorder.
            const bool useRecorder = kv.getValue<uint32_t>("proxy.useRecorder") == 1;
            if (useRecorder) {
                // URL for storing containers.
                stringstream recordingURL;
                recordingURL << "file://" << "proxy_" << TimeStamp().getYYYYMMDD_HHMMSS() << ".rec";
                // Size of memory segments.
                const uint32_t MEMORY_SEGMENT_SIZE = getKeyValueConfiguration().getValue<uint32_t>("global.buffer.memorySegmentSize");
                // Number of memory segments.
                const uint32_t NUMBER_OF_SEGMENTS = getKeyValueConfiguration().getValue<uint32_t>("global.buffer.numberOfMemorySegments");
                // Run recorder in asynchronous mode to allow real-time recording in background.
                const bool THREADING = true;
                // Dump shared images and shared data?
                const bool DUMP_SHARED_DATA = getKeyValueConfiguration().getValue<uint32_t>("proxy.recorder.dumpshareddata") == 1;

                m_recorder = unique_ptr<Recorder>(new Recorder(recordingURL.str(), MEMORY_SEGMENT_SIZE, NUMBER_OF_SEGMENTS, THREADING, DUMP_SHARED_DATA));
            }

            // Create the camera grabber.
            const string NAME = getKeyValueConfiguration().getValue<string>("proxy.camera.name");
            string TYPE = getKeyValueConfiguration().getValue<string>("proxy.camera.type");
            std::transform(TYPE.begin(), TYPE.end(), TYPE.begin(), ::tolower);
            const uint32_t ID = getKeyValueConfiguration().getValue<uint32_t>("proxy.camera.id");
            const uint32_t WIDTH = getKeyValueConfiguration().getValue<uint32_t>("proxy.camera.width");
            const uint32_t HEIGHT = getKeyValueConfiguration().getValue<uint32_t>("proxy.camera.height");
            const uint32_t BPP = getKeyValueConfiguration().getValue<uint32_t>("proxy.camera.bpp");

            if (TYPE.compare("opencv") == 0) {
                m_camera = unique_ptr<Camera>(new OpenCVCamera(NAME, ID, WIDTH, HEIGHT, BPP));
            }
            if (TYPE.compare("ueye") == 0) {
#ifdef HAVE_UEYE
                m_camera = unique_ptr<Camera>(new uEyeCamera(NAME, ID, WIDTH, HEIGHT, BPP));
#endif
            }

            if (m_camera.get() == NULL) {
                cerr << "No valid camera type defined." << endl;
            }
        }


        void Proxy::tearDown() {
            // This method will be call automatically _after_ return from body().
        }

        void Proxy::distribute(Container c) {
            // Store data to recorder.
            if (m_recorder.get() != NULL) {
                // Time stamp data before storing.
                c.setReceivedTimeStamp(TimeStamp());
                m_recorder->store(c);
            }

            // Share data.
            getConference().send(c);
        }

        // This method will do the main data processing job.
        odcore::data::dmcp::ModuleExitCodeMessage::ModuleExitCode Proxy::body() {
            uint32_t captureCounter = 0;
            uint32_t sendCounter = 0;
            uint32_t delayCounter = 0;
            bool newCommand = false;
            string port = "/dev/ttyACM0";
            unsigned long baud = 57600;
            string result = "";
            string decoded = "";
            string DELIM_KEY_VALUE = "=";
            string DELIM_PAIR = ";";
            string SPEED_KEY = "speed";
            string ANGLE_KEY = "angle";

            serial::Serial my_serial(port, baud, serial::Timeout::simpleTimeout(1000));

            // Test if the serial port has been created correctly.
            //cout << "Is the serial port open?";
            if(my_serial.isOpen()){
              cout << " The serial port is open in port : " << port  << endl;
            } else {
              cout << " Couldnt open the port!" << endl;
            }

            while (getModuleStateAndWaitForRemainingTimeInTimeslice() == odcore::data::dmcp::ModuleStateMessage::RUNNING) {
                // Delay all communication for a short while to not overflow the arduino
                if (delayCounter < 40){
                  delayCounter++;
                } else {
                  // Capture frame.
    		            if (m_camera.get() != NULL) {
    		            	
    		                odcore::data::image::SharedImage si = m_camera->capture();

    		                Container c(si);
    		                distribute(c);
    		                captureCounter++;
    		            }

                    // Create objects where we get speed and steering angle from
    		            Container containerVehicleControl = getKeyValueDataStore().get(automotive::VehicleControl::ID());
    		            VehicleControl vc = containerVehicleControl.getData<VehicleControl>();
                    
    		            double vcSpeed = vc.getSpeed();
    		            int16_t speedTemp = vcSpeed;
                    // Set the speed to constant values
    		            if (vcSpeed > 0){
    		              speedTemp = 1560;
    		            } else if (vcSpeed < 0){
    		              speedTemp = 1240;
    		            } else {
    		              speedTemp = 1500;
    		            }
    		            vcSpeed = speedTemp;
                    
    		            double vcAngle = vc.getSteeringWheelAngle();
                    int vcDegree= vcAngle+99;
                    // Convert steering angle from radiants to degrees
    		            // int16_t vcDegree = (vcAngle * cartesian::Constants::RAD2DEG);
                    // Send the exact value we want to set steering at
    		           
                    
    		            sendCounter++;  // Dont send to arduino every loop
    		            if(my_serial.isOpen() && sendCounter == 5){ //we use the counter to send only once in 5 loops
    		               stringstream strStream;
    		               string toSend = "";
    		               strStream << SPEED_KEY<<DELIM_KEY_VALUE<<vcSpeed<<DELIM_PAIR <<ANGLE_KEY<<DELIM_KEY_VALUE
    		               << vcDegree  <<DELIM_PAIR<<","; //add the information in a stream
    		               strStream >> toSend;  // convert the stream to string		               
    		               my_serial.write(toSend);   //send the string over the serial 		              
    		               sendCounter = 0;

                       
    		            }
                    // Read to a buffer for incomiing data
    		            //size_t readSize = ;
    		            size_t size = 1000;
                    string eol = ",";
                    while (my_serial.available() > 0 && newCommand == false){                   
    		              result = my_serial.readline(size,eol);  		          
                      cout << "NEW COMMAND" << endl;
    		              newCommand = true; // When a full netstring has arrived    
                    }
    		            if (newCommand){
                 
    		              sbdDistribute(result); // Distribute SensorBoardData
                      vdDistribute(result); // Distribute VehicleData 
    		              newCommand = false;
    		              result = ""; // emtying the buffer
    		            }

		              }
		        }

		        cout << "Proxy: Captured " << captureCounter << " frames." << endl;

		        return odcore::data::dmcp::ModuleExitCodeMessage::OKAY;
        }

        // Distribute VehicleData. Takes a string as input.
        void Proxy::vdDistribute(const string result){
          Container containerVehicleData = getKeyValueDataStore().get(automotive::VehicleData::ID());
          VehicleData vd = containerVehicleData.getData<VehicleData> ();
          bool hasErrorPath = false;
          double cmTrav;
          size_t index1 = result.find("WP:");
          size_t index1Num = result.find(":",index1) +1;
         
          try {
            cmTrav = stoi(result.substr(index1Num ,  result.find(";",index1Num) - index1Num) );
            
          }
          catch (...){
            cout << "WP STOI" << endl;
            hasErrorPath = true;
          }
          if (!hasErrorPath){
            vd.setAbsTraveledPath(cmTrav);
          }
          // catch (std::out_of_range&){
          //   cerr << "STOI: Out of range." << endl;
          // }

          

          //cout << "cmTrav: " << vd.getAbsTraveledPath() << endl;

          Container c3(vd);
          getConference().send(c3);
        }

        // Distribute SensorBoardData. Takes a string as input.
        void Proxy::sbdDistribute(const string result){

          Container containerSensorBoardData = getKeyValueDataStore().get(automotive::miniature::SensorBoardData::ID());
          SensorBoardData sbd = containerSensorBoardData.getData<SensorBoardData> ();

          bool hasErrorIRFR = false;
          bool hasErrorIRRR = false;
          bool hasErrorIRRC = false;
          bool hasErrorUSC = false;
          bool hasErrorUSR = false;

          int irFrontRight;
          int irRearRight;
          int irRearCenter;
          int usFrontCenter;
          int usFrontRight;
        
          size_t index1 = result.find("IRFR:"); // find the word
          size_t index2 = result.find("IRRR:");
          size_t index3 = result.find("IRRC:");
          size_t index4 = result.find("USC:");
          size_t index5 = result.find("USR:");

          size_t index1Num = result.find(":",index1) +1; // take the position of the number right after the ":"
          size_t index2Num = result.find(":",index2) +1;

          size_t index3Num = result.find(":",index3) +1;

          size_t index4Num = result.find(":",index4) +1;

          size_t index5Num = result.find(":",index5) +1;

         
           try {
           
            irFrontRight = stoi(result.substr(index1Num, result.find(";",index1Num) - index1Num) ); // take only the number!
          }catch(...){
            cout << "IRFR STOI" << endl;
            hasErrorIRFR=true;} // it has an error! so we dont check it again
          
          try{
            irRearRight = stoi(result.substr(index2Num, result.find(";",index2Num) - index2Num));
          }catch(...){
            cout << "IRRR STOI" << endl;
            hasErrorIRRR=true;}
          
          try{
            irRearCenter = stoi(result.substr(index3Num, result.find(";",index3Num) - index3Num) );
          }catch(...){
            cout << "IRRC STOI" << endl;
            hasErrorIRRC=true;}
          
          try{
            usFrontCenter = stoi(result.substr(index4Num, result.find(";",index4Num) - index4Num));
          }catch(...){
            cout << "USC STOI" << endl;
            hasErrorUSC=true;}
          
          try{
            usFrontRight = stoi(result.substr(index5Num, result.find(";",index5Num) - index5Num));
          }catch(...){
            cout << "USR STOI" << endl;
            hasErrorUSR=true;}
           
       

          if (!hasErrorIRFR){ //no error.. 
            //the part below was used to take 4 values of the sensor and save it as once so the data would more reliable, however it was removed since there were too little and late data!
            //IRFR[counterFR]=irFrontRight;

            //cout << IRFR[counterFR] << "--- is the value and the Array "<<counterFR<<"SET to " <<irFrontRight<<endl;
            //counterFR++;
             sbd.putTo_MapOfDistances(0,irFrontRight); // we save the value to sbd
            
              
          }
          if (!hasErrorIRRC){
            sbd.putTo_MapOfDistances(1, irRearCenter);
          }
          if (!hasErrorIRRR){

             // IRRR[counterRR]=irRearRight;
             // counterRR++;
             sbd.putTo_MapOfDistances(2, irRearRight);
          }
          if (!hasErrorUSC){
             sbd.putTo_MapOfDistances(3, usFrontCenter);
          }
          if (!hasErrorUSR){
             sbd.putTo_MapOfDistances(4, usFrontRight);
          }
          //this is a part of getting the average of the sensors:
          // if (counterFR == 4){
          //   counterFR =0;
          //   cout << IRFR[0] << " -- 0" <<endl;
          //   cout << IRFR[1] << " -- 1" <<endl;
          //   cout << IRFR[2] << " -- 2" <<endl;
          //   cout << IRFR[3] << " -- 3" <<endl;
          //   for (int i=0; i<4; i++){
          //     //cout <<"The "<< i << "element is equal to: " << IRFR[i] <<endl;
          //     averageFR= averageFR+ IRFR[i];
              
              
          //   }
          //   averageFR= averageFR/4;
          //   //cout << averageFR << " YOYOYOY" <<endl;
          //   sbd.putTo_MapOfDistances(0,averageFR);
          //   averageFR=0;

          // }
          
          // if (counterRR == 4){
          //   counterRR =0;
          //   for (int i=0; i<4; i++){
          //     averageRR= IRRR[i]+averageRR;
          //   }
          //   averageRR= averageRR/4;
          //   sbd.putTo_MapOfDistances(2,averageRR);
          // }

          cout << sbd.getValueForKey_MapOfDistances(0) <<endl;
          cout <<sbd.getValueForKey_MapOfDistances(1) <<endl;
          cout <<sbd.getValueForKey_MapOfDistances(2) <<endl;
          cout <<sbd.getValueForKey_MapOfDistances(3) <<endl;
          cout <<sbd.getValueForKey_MapOfDistances(4) <<endl;
            //cout << irFrontRight<<irRearRight<<usFrontRight<<usFrontCenter << endl;
            // sbd.putTo_MapOfDistances(0, irFrontRight);
            // sbd.putTo_MapOfDistances(1, irRearRight);
            //  sbd.putTo_MapOfDistances(2, irRearCenter);
            //  sbd.putTo_MapOfDistances(3, usFrontCenter);
            //  sbd.putTo_MapOfDistances(4, usFrontRight);
            //   cout << "irFrontRight: " << sbd.getValueForKey_MapOfDistances(0) << endl;
            //  cout << "irRearRight: " << sbd.getValueForKey_MapOfDistances(1) << endl;
            //  cout << "irRearCenter: " << sbd.getValueForKey_MapOfDistances(2) << endl;
            // cout << "usFrontCenter: " << sbd.getValueForKey_MapOfDistances(3) << endl;
            // cout << "usFrontRight: " << sbd.getValueForKey_MapOfDistances(4) << endl;
            Container c2(sbd);
            getConference().send(c2);
          
        }

    }
} // automotive::miniature
